<template src="./week.html"></template>
<script src="./week.js"></script>
<style scoped lang="css" src="./week.css"></style>