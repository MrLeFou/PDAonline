<template src="./footer.html"></template>
<script src="./footer.js"></script>
<style scoped lang="css" src="./footer.css"></style>
