export default {
    name: 'nav-bar',
    props: {
        title: String,
        userName: String,
        userStatus: String,
    }
};