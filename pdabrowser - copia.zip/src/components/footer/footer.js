export default {
    name: "AppFooter",
};
