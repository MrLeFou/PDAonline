import moment from "moment";

export default {
    name: "CalendarFilter",
    props: {
        selectedMonth: {
            type: Object,
        },
        selectedYear: {
            type: Number,
        }
    },
    watch: {
        selectedYear(){
            this.fillMonths();
        }
    },
    computed: {
        selectedMonthModel: {
            get() {
                return this.selectedMonth;
            },
            set(value) {
                this.$emit("month-changed", value)
            }
        }
    },
    data() {
        return {
            months: [],
        };
    },
    methods: {
        fillMonths(){
            this.months = [];
            
            for (let i = 0; i < 12; i++) {
                let month = moment().month(i).year(this.selectedYear);
    
                this.months.push({
                    displayName: month.format("MMMM"),
                    index: i,
                    days: month.daysInMonth(),
                })
            }
        }
    },
    created() {
        this.fillMonths();
        this.selectedMonthModel = this.months[0];
    }
};
