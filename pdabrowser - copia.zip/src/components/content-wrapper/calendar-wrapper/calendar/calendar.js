export default {
    name: "Calendar",
    props: {
        selectedMonth: {
            type: Object,
        },
        selectedYear: {
            type: Number,
        }
    },
    data() {
        return {

        };
    },
    created() {

    },
};
