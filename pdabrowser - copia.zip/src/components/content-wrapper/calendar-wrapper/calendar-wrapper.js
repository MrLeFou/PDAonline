import Filters from "./calendar-filters"
import Calendar from "./calendar"

export default {
    name: "calendar-wrapper",
    components: {
        Filters,
        Calendar,
    },
    props: {
        selectedYear: {
            type: Number,
        },
    },
    data() {
        return {
            selectedMonth: null,
        };
    },
    methods: {
        onMonthChanged(value) {
            this.selectedMonth = value;
        },
    },
    created() {

    },
};
