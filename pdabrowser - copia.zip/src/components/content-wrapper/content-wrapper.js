import moment from "moment";

import CalendarWrapper from "./calendar-wrapper"

export default {
    name: 'content-wrapper',
    components: {
        CalendarWrapper
    },
    data() {
        return {
            selectedYear: null,
            years: [
                moment().year() - 5,
                moment().year() - 4,
                moment().year() - 3,
                moment().year() - 2,
                moment().year() - 1,
                moment().year(),
                moment().year() + 1,
                moment().year() + 2,
                moment().year() + 3,
                moment().year() + 4,
                moment().year() + 5,
            ]
        };
    },
    created() {
        this.selectedYear = moment().year();
    },
    methods: {

    },
    computed: {
        
    },
};
