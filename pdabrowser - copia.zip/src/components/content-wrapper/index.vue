<template src="./content-wrapper.html"></template>
<script src="./content-wrapper.js"></script>
<style scoped lang="css" src="./content-wrapper.css"></style>
